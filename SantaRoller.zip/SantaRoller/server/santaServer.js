/*
	SERVER SIDE CODE

	The server for this will handle requests and will basically manage the 3 datatypes in the data base
		Requests
			creating new users with hash passwords			
			allowing users to login

			add new cook books to db (making is client side)
			get cookbook from db

			add new recipe
			get recipe

			find a user by username
			find a cookbook by keyword or all
			find a recipe by keyword or all


		
			

*/


//  HOST and PORT update host for droplet server when ready
const hostname = '143.198.178.186';
const port = 80;



const express = require('express');
const mongoose = require('mongoose')
const parser = require('body-parser');
const cookieParser = require('cookie-parser')



const app = express();
app.use(parser.json());
app.use(parser.urlencoded({extended: true}));

app.use(parser.text({type: '*/*'}));
app.use(cookieParser());


//create the connection to database
const db = mongoose.connection;
const localDBURL = 'mongodb://127.0.0.1/SantaRoller';

//Set up the connection to the DB
mongoose.connect(localDBURL, { useNewUrlParser: true });
db.on('error', console.error.bind(console, 'MongoDB connection error:'));




//listener
//this will print on start with name and port
app.listen(port, hostname, () => 
  {
    console.log(`Server running at http://${hostname}:${port}/`);
  }
);


// Tell the express app to pare any body type and to use a cookie parser

app.use(express.static('public_html'))
app.use('/app/*', authenticate)
app.get('/', (req, res) => { res.redirect('/account/account.html'); });




var Schema = mongoose.Schema;


//this schema will track the user's wishlist and who they picked and if they have been picked the user should not be able to find out who picked them
var userSchema = new Schema(
{
	UserName: String,
	Password: String,

	FirstName: String,
	LastName: String,


	Wishlist: String,

	PickState: String, //PICKED or AVAILABLE

	SecretPick: String, //username of picked person. to use to call up the stuffs

});

//to save the chat
var chatSchema= new Schema({ sayer: String, message: String,});


//MODELS
var UserModel = mongoose.model('User', userSchema);
var ChatModel = mongoose.model('Chat', chatSchema)



// sssssssssssssssssssssssssse             SESSIONS                ssssssssssss


// Some code for tracking the sessions on the server

// map usernames to timestamp
var sessions = {};
const LOGIN_TIME = 600000;

function filterSessions() {

  var now = Date.now();
  for (x in sessions)
  {
   	console.log('Sessions: ' + x)
    username = x;
    time = sessions[x];
    if (time + LOGIN_TIME < now) {
      delete sessions[x];
    }
  }
}

//filter the sessions every 2 seconds
setInterval(filterSessions, 2000);


function addSession(username) {
  var now = Date.now();
  sessions[username] = now;
}

function doesUserHaveSession(username) {
  return username in sessions;
}


function authenticate(req, res, next) {
  var c = req.cookies;
  if (c && c.login) 
  {
    var username = c.login.username;

    console.log("authenticating: " + username);

    if (doesUserHaveSession(username)) {
    	console.log("user is valid");
      addSession(username);
      next();
    } else 
    {
    	console.log("user is failed authentication");

  		res.redirect('./index.html');
    }
  }
}


//sssssssssssssssssssssssEND of SESSIONS


// rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr REQUEST HANDLES


//user related
//this gets all users debug purposes
app.get('/get/users/',(req, res) =>
{
	UserModel.find({})
	.exec(function (err, results)
		{
			if (err) return handleError(err);
			res.end(JSON.stringify(results));
		});
});


//log in
app.post('/account/login/',(req, res) =>
{
	console.log("attempting to log in: " + req.body.username);

	//when we get a login request we will look for the user
	UserModel.find({UserName : req.body.username})
	.exec(function (err, results)
		{
			console.log(results.length);

			if (err) return res.end('Login failed: User doesnt exist');
			//if we find the user then we can check the password
			else if(results.length == 1) 
			{
				//if we have one result then we can check the password these passwords are hash values
				console.log(results[0].Password);
				if (results[0].Password === req.body.password)
				{
					//if the passwords match then yay we add the user to the session and then implant a cookie
					addSession(req.body.username);
        			res.cookie("login", {username: req.body.username},{firstName: results[0].FirstName},{lastName: results[0].LastName}, {maxAge: 600000}); //set for 10 minutes
					res.end('GRANTED:'+results[0].FirstName); // we send granted back tot he client
				}
				else res.end('Login failed: passwords do not match');
			}
			else
			{
				console.log('Error more than 1 result found' + results);
				res.end('Login failed: could not locate username');

			}
		});
});


// make new user with post user and pass in body pass should be hashed
app.post('/account/create/user',(req, res) =>
{

	console.log('creating new user!');

	//to make a user we need to see its already take so first we search
	UserModel.find({UserName: req.body.username})
	.exec((err, results) =>
	{
			if (err) return res.end('Login failed: User doesnt exist');
			
			//if we find nothing then it means we can create a new account with that name
			if (results.length > 0)
			{
				//if we find a user with that name then return this
				res.send('Username already taken!');
			}
			else
			{

					//create the new object out of the db schema and then save it
				var nu = UserModel({
						UserName: req.body.username,
						Password: req.body.password,		
						FirstName:req.body.firstname,
						LastName: req.body.lastname,		
						PickState: 'AVAILABLE',
						Wishlist: 'Wishlist is empty!', 
						SecretPick: 'none',

				});

				nu.save(function (err) { if (err) console.log('FAIL user not added'); });
				console.log("New user saved!" + nu);
				res.send('New User Added!');	

			}
	});

});




//  END OF ACCOUNT HANDLES

app.get('/clear', (req, res) => {
    db.dropDatabase();
    res.send('DB is clear');
});






// SANTA Handles


app.get('/app/roll/:SANTA', (req,res) =>
{
	console.log("HOHOHO someone wants to pick a giftee");
	secretSantaPick = '';
	//we will get the santa person first
	UserModel.find({UserName: req.params.SANTA})
	.exec((err, santa) =>
	{
		if (err) { return handleError(err); }

		if (santa[0].SecretPick == 'none')
		{
			//get the list of available users and then roll to get a random one
			UserModel.find({PickState: 'AVAILABLE'})
			.exec((err, results) =>
			{

				console.log("HOHOHO we have these people to choose from " + results );

				if (err) return handleError(err);
				

				rng = Math.floor(Math.random()* results.length);

				console.log("HOHOHO you will get " + results[rng]);


				secretSantaPick = results[rng].UserName + ':' + results[rng].FirstName + " " + results[rng].LastName;

				res.send(secretSantaPick);
			});
		}
		else
		{
			res.send('WAIT: You already made your pick');
		}
	});

});


app.get('/app/save/:SANTA/:GIFTEE', (req,res) =>
{



	//we will get the santa person first
	UserModel.find({UserName: req.params.SANTA})
	.exec((err, santa) =>
	{
		if (err) { return handleError(err); }

		if (santa[0].SecretPick == 'none')
		{
			santa[0].SecretPick = ''+ req.params.GIFTEE;
			santa[0].save();
			

			UserModel.find({UserName: req.params.GIFTEE})
			.exec((err, results) =>
			{
				if (err) { return handleError(err); }

				results[0].PickState = 'PICKED';
				results[0].save();
				res.send('SAVE SUCCESSFUL');
			});
		}
		else
		{
			res.send('WAIT: You already have a pick!');

		}
	});
	
});

//last is getting the wishlist to the user
app.get('/app/get/pick/:SANTA', (req,res) =>
{

	UserModel.find({UserName: req.params.SANTA}).exec((err, santa)=>
	{

		if (err){return handleError(err)}

		if (santa[0].SecretPick != 'none')
		{
			var santaGiftee = santa[0].SecretPick;

			if (santaGiftee =='none')
			{
				res.end('Need to make a pick!');
			}
			else
			{

				UserModel.find({UserName: santaGiftee}).exec((err, giftee)=>
				{
					if (err){return handleError(err)}
					var returnString = giftee[0].FirstName +' '+ giftee[0].LastName + ' : ' + giftee[0].Wishlist;
					res.end(returnString);
				});
			}
		}
	});


});





app.post('/app/save/wishlist/:SANTA', (req,res) =>
{
	

	wishlistUpdate = req.body.update;
	
	UserModel.find({UserName: req.params.SANTA}).exec((err, santa)=>
		{
			if (err){return res.end(err)}

			santa[0].Wishlist = wishlistUpdate;
			santa[0].save();
			res.end(santa[0].Wishlist);
	});

});



app.get('/app/get/wishlist/:SANTA', (req,res) =>
{
	

	wishlistUpdate = req.body.update;
	
	UserModel.find({UserName: req.params.SANTA}).exec((err, santa)=>
		{
			if (err){return res.end(err)}

			res.end(santa[0].Wishlist);
	});

});
















///////////////////////////////////////  cccccccccccccccccccccccc CHAT!!!!!
app.get('/app/chat/get', (req, res) => {
	ChatModel.find({})
	.exec( (error, results) => {
		if (error) { return res.end('ERROR'); }
		var resultString = '';
		for (i in results) {
			r = results[i];
			resultString += '<b id="output">' + r.sayer + ': </b>' + r.message + '<br>';
		}
		res.end(resultString);
	});
});

app.post('/app/chat/post/:USERNAME/:MESSAGE', (req, res) => {

	var newMessage = new ChatModel({sayer: req.params.USERNAME, message: req.params.MESSAGE});

	newMessage.save( (error) => {
        if (error) res.end('PROBLEM: ' + res.status);
        res.end('SAVED');
    });
});

app.get('/clear/admin/nate/xgr345453lpow12', (req, res) => {
    db.dropDatabase();
});


