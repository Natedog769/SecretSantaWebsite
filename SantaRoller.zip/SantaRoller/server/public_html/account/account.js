/*
	CLIENT SIDE CODE

	These are the login methods
	users can make a new account or login to an existing one

*/



function login(){
	var username = $('#LoginUsernameInput').val();
	var password = $('#LoginPasswordInput').val();
	



	$.ajax({
		url:`/account/login/`,
		method:'POST',
		data: {
			username: username,
			password: password,
		},
		success: (data) => {
			
			splitData = data.split(':')

			if (data.includes('GRANTED')) {
				window.location.href = '/app/home.html';
				localStorage.setItem('UserName', username);
				localStorage.setItem('FirstName', splitData[1]);
			}
			else
			{
				console.log(data);
				alert(data);
			}
		}
	})	
}



//This function will send a request to add a user to the db
function createAccount()
{
	let username = $('#NewUserNameInput').val();
	let password = $('#NewUserPassInput').val();
	var firstName = $('#NewFirstNameInput').val();
	var lastName = $('#NewLastNameInput').val();

	console.log('Making new user!');

	if (username && password && firstName && lastName)
	{
		$.ajax({
			url: `/account/create/user`,
			method: 'POST',
			data: {
				'username': username,
				'password': password,
				'firstname': firstName,
				'lastname': lastName,
			},
			success: (data) => {
				alert(data);
			}
		});
	}
}


function clearDB() {
	$.ajax({
		url: '/clear',
		method: 'GET',
		success: (data) => {
			$('#body').html = '';
			alert('Database is empty.');
		}
	});
}