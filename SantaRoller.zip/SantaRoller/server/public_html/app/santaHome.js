function welcomeUser() {
    fname = localStorage.getItem('FirstName');
    $.ajax({
        url: '/app/home.html',
        method: 'GET',
        success: (data) => {
            $('#welcome-user').text(`Hello Santa ${fname}!`)
        }
    });
}





//this will get a name from the server
function rollForPick()
{
    console.log('Rolling for a secret santa pick!')

    $.ajax({
        url:`/app/roll/` + localStorage.getItem('UserName'),
        method:'GET',
        data: {
        },
        success: (data) => {
            console.log('Ok my claus says you get   '+ data);

            $('#pickOutput').text(data);
            localStorage.setItem('Pick', data);
        }
    });
}


//when the user saves the pick they will get to see the picked persons wishlist
function savePick()
{
    var gifteeUser = localStorage.getItem('Pick').split(':')[0];

    

      $.ajax({
        url:`/app/save/` + localStorage.getItem('UserName') +'/' + gifteeUser,
        method:'GET',
        data: {
        },
        success: (data) => {
            console.log('Ok my claus says you get   '+ data);
            
            localStorage.setItem('Pick', data);
        }
    });
}


function getPickInfo()
{
    console.log('fetching pick wishlist');

      $.ajax({
        url:`/app/get/pick/`+ localStorage.getItem('UserName'),
        method:'GET',
        data: {
        },
        success: (data) => {
            //here we output to the divwe should be getting back a whole obj or just a wishlist string....
            console.log(data);
            var split = data.split(':');

            $('#pickOutput').text(split[0]);
            $('#rnpOutput').text(split[1]);

        }
    });
}




//this function will get the user's wishlist to be called on save press and onload
function getMyWishList()
{
    $.ajax(
    {
        url:`/app/get/wishlist/`+localStorage.getItem('UserName'),
        method:'GET',
        success: (data) => {
            //here we output to the divwe should be getting back a whole obj or just a wishlist string....

             $('#wishlistEdit').val(data);

        }

    })
}


function saveMyWishlist()
{
    //this function will save the wishlist the text from the wishlist box
    console.log('Saving my wishlist')

    var wishlistUpdate = $('#wishlistEdit').val();

    $.ajax(
    {
        url:`/app/save/wishlist/`+localStorage.getItem('UserName'),
        method:'POST',
        data:
        {
            update: wishlistUpdate,
        },
        success: (data) => {
            //here we output to the divwe should be getting back a whole obj or just a wishlist string....
            $('#wishlistEdit').val(data);
            alert('Wish list saved!');

        }

    })

}






function getMessage()
{
    chatOutput = $('#chatOutput');
    $.ajax({
        url: `/app/chat/get`,
        method: 'GET',
        success: (data) => {
            chatOutput.html(data);
            chatOutput.scrollTop(chatOutput.scrollHeight);
        }
    });
}


setInterval(() => getMessage(), 1000);



function sendMessage()
{
    username = localStorage.getItem('UserName');
    message = $('#chatBar').val();

    $.ajax({
        url: '/app/chat/post/' + encodeURIComponent(username) + '/' + encodeURIComponent(message),
        method: 'POST',
        data: {
            userName: username,
            message: message
        },
        success: (data) => {
            $('#chatBar').val('');
        }
    });
}



